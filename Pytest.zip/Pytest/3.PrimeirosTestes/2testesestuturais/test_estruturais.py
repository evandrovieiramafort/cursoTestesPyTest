
def test_listas_iguais():
    lista_esperada = [1,2,3,4,5]
    lista_resultado = [1,2,3,4,5]
    assert lista_resultado == lista_esperada, "As listas não são iguais."