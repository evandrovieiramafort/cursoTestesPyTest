def test_sim():
    assert sum([1,2,3]) == 7