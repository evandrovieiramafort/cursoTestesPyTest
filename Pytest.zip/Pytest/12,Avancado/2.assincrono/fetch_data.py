import asyncio
async def fetch_data():
    await asyncio.sleep(1)
    return {'data': 'some data'}