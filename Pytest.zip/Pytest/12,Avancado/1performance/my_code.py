import time

def long_running_function():
    time.sleep(4)
    return "finished"